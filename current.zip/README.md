# README #

See all open tabs extention for chrome.
inspired by firefox tab list view.


### Purpose ###

* Chrome extention
* Version : 1.0.2.1
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

